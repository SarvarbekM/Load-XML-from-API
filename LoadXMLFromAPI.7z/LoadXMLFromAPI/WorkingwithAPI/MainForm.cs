﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WorkingwithAPI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            try
            {
                if (!string.IsNullOrEmpty(textBox1.Text))
                {
                    string url = textBox1.Text;
                    XElement xml = XElement.Load(url);
                    if (xml.Element("status").Value == "OK")
                    {                        
                       richTextBox1.Text = xml.Element("result").Element("formatted_address").Value;                        
                    }
                    else
                    {
                        richTextBox1.Text = String.Concat("Ocorreu o seguinte erro: ", xml.Element("status").Value);
                    }
                }
                else
                {
                    MessageBox.Show("Link is empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };
        }
    }
}
